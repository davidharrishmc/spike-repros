**mireg\* accessed with V=1 raise virtual-instruction instead of illegal-instruction**

mireg and mireg2–mireg6 are M-level CSRs, so an access from VS or VU should raise an illegal-instruction exception. The H extension raises virtual-instruction only for accesses that HS-mode would be allowed to make. Spike raises virtual-instruction in two cases:

- From VU, always. The `state->v && state->prv == PRV_U` check in `sscsrind_reg_csr_t::verify_permissions` was added by #2221 for sireg\*/vsireg\*, but mireg\* use the same class.
- From VS, when mstateen0.CSRIND=1 and hstateen0.CSRIND=0. hstateen0.CSRIND controls only siselect, sireg\*, vsiselect and vsireg\*, not mireg\*.

In both cases these checks run before the base privilege check in `csr_t::verify_permissions`.

Reproducer (attached): `make run` with `--isa=rv64gch_smstateen_smcsrind_sscsrind`. `mireg.S` executes `csrr a0, mireg` once from VU and once from VS, then writes tohost = 100×(first mcause) + (second mcause). The expected result is 202. Spike f2207b5a gives 2222 (master fb225a5f has the same code), and the `-l` log shows `exception trap_virtual_instruction` at the `csrr`.

A possible fix is to run the base privilege check first for M-level CSRs:

```diff
 void sscsrind_reg_csr_t::verify_permissions(insn_t insn, bool write) const {
+  // mireg* are M-level CSRs: below M, they raise illegal instruction before any stateen or V check
+  if (get_field(address, 0x300) == PRV_M)
+    csr_t::verify_permissions(insn, write);
+
   if (proc->extension_enabled(EXT_SMSTATEEN)) {
```

With this patch the reproducer gives 202. sireg (0x151) still raises virtual-instruction in both cases, which is correct. #1893 reported a related mireg/sireg shared-class problem.

Found with the RISC-V architectural tests (H_vucsr).
